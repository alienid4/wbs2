#!/usr/bin/env bash
# 一鍵套用 patch —— 在解開的這個資料夾裡執行：  sudo bash patch.sh
#
# 跑完就結束，不需要再手動做別的事。它會：
#   換檔 → 修換行/權限 → 重啟 cl-wbs.service → 驗證
#
# 出事怎麼辦：畫面會印出備份目錄與一行還原指令。
# 可以重跑：同一包重複套用不會壞，只是再備份一次。
set -uo pipefail

HERE="$(cd "$(dirname "$0")" && pwd)"
APP="${CLWBS_APP:-/opt/cl_wbs}"
SERVICE="${CLWBS_SERVICE:-cl-wbs.service}"
SVC_USER="${CLWBS_USER:-wbs}"
PORT="${CLWBS_PORT:-3001}"
TS="$(date +%Y%m%d_%H%M%S)"
BACKUP="$APP/backups/patch_backup_$TS"

ver_of() { grep -oE '[0-9]+\.[0-9]+\.[0-9]+' "$1" 2>/dev/null | head -1; }
OLD_VER="$(ver_of "$APP/version.json")"
NEW_VER="$(ver_of "$HERE/files/version.json")"

echo "════════════════════════════════════════════════"
echo " 套用 patch： $(basename "$HERE")"
echo " 目標位置　： $APP"
echo " 時間　　　： $(date '+%F %T')"
echo " 版本　　　： ${OLD_VER:-未知} → ${NEW_VER:-未變更}"
echo "════════════════════════════════════════════════"

if [ -f "$HERE/MANIFEST.txt" ]; then
  echo
  echo "這包改了什麼："
  sed -n '/== 這包改了什麼 ==/,/^$/p' "$HERE/MANIFEST.txt" | sed '1d;/^$/d' | sed 's/^/  · /'
fi

if [ -n "$OLD_VER" ] && [ "$OLD_VER" = "$NEW_VER" ]; then
  echo
  echo "  註：版號相同，這包可能已經套過了。重跑無害，會照樣覆蓋檔案並重啟。"
fi

[ "$(id -u)" = "0" ] || { echo "!! 請用 sudo 執行： sudo bash patch.sh"; exit 1; }
[ -d "$APP" ] || { echo "!! 找不到 $APP —— 這台還沒安裝過，請先跑 tools/install_server.sh 做完整安裝"; exit 1; }
[ -d "$HERE/files" ] || { echo "!! 這包裡沒有 files/，patch 不完整"; exit 1; }
id "$SVC_USER" >/dev/null 2>&1 || { echo "!! 找不到服務帳號 $SVC_USER"; exit 1; }

trap 'echo; echo "!! 中斷了。檔案可能已經換成新版、但服務還沒重啟。"; \
      echo "   請直接再跑一次（這支腳本冪等，重跑無害）： sudo bash $0"; exit 130' INT TERM

# ===== 1. 備份 =====
echo
echo "[1/4] 備份即將被覆蓋的檔案 → $BACKUP"
sudo -u "$SVC_USER" mkdir -p "$BACKUP"
COUNT=0
while IFS= read -r rel; do
  src="$APP/$rel"
  if [ -f "$src" ]; then
    sudo -u "$SVC_USER" mkdir -p "$BACKUP/$(dirname "$rel")"
    sudo -u "$SVC_USER" cp -p "$src" "$BACKUP/$rel"
    COUNT=$((COUNT+1))
  fi
done < <(cd "$HERE/files" && find . -type f | sed 's|^\./||')
echo "$BACKUP" > "$APP/backups/.last_backup" 2>/dev/null || true
echo "  已備份 $COUNT 個既有檔案"

# ===== 2. 套用新檔案（以服務帳號身分寫入，維持檔案 owner 是 wbs 不是 root） =====
echo
echo "[2/4] 套用新檔案"
(cd "$HERE/files" && find . -type f | sed 's|^\./||') | while IFS= read -r rel; do
  sudo -u "$SVC_USER" mkdir -p "$APP/$(dirname "$rel")"
  sudo -u "$SVC_USER" cp -p "$HERE/files/$rel" "$APP/$rel"
  echo "  ✓ $rel"
done

# ===== 3. 修換行 + 權限 =====
# 檔案經 Windows 中轉會變成 CRLF，bash 會直接噴 $'\r': command not found。
echo
echo "[3/4] 修正換行符與權限"
find "$APP/tools" -maxdepth 2 -name '*.sh' -exec sed -i 's/\r$//' {} + 2>/dev/null
find "$APP/tools" -maxdepth 2 -name '*.sh' -exec chmod +x {} + 2>/dev/null
echo "  ✓ 換行符已正規化"

# ===== 4. 重啟並驗證 =====
echo
echo "[4/4] 重啟 $SERVICE"
systemctl restart "$SERVICE"
sleep 2

OK=1
if ! systemctl is-active --quiet "$SERVICE"; then
  echo "  ✗ $SERVICE 沒起來"
  journalctl -u "$SERVICE" -n 40 --no-pager 2>/dev/null | tail -40
  echo "  -- 用服務帳號直接 import app.server --"
  sudo -u "$SVC_USER" bash -c "cd '$APP' && python3 -c 'import app.server'" 2>&1
  echo "  -- SELinux --"
  getenforce 2>/dev/null || echo "（沒有 getenforce）"
  OK=0
fi

RESP=""
if [ "$OK" = "1" ]; then
  RESP="$(curl -fsS --max-time 5 "http://127.0.0.1:$PORT/api/version" 2>/dev/null || echo "")"
  if [ -z "$RESP" ]; then
    echo "  ✗ http://127.0.0.1:$PORT/api/version 沒有回應"
    OK=0
  else
    echo "  ✓ /api/version 回報：$RESP"
  fi
fi

echo
echo "════════════════════════════════════════════════"
if [ "$OK" = "1" ]; then
  echo "✅ patch 完成：版本 ${OLD_VER:-未知} → ${NEW_VER:-未變更}，服務已在跑"
  echo "   服務： http://127.0.0.1:$PORT"
  echo "   備份： $BACKUP"
else
  echo "!! 沒有完成 —— 上面的錯誤訊息就是原因"
  echo
  echo "   要還原成套用前的狀態："
  echo "     sudo cp -rp $BACKUP/* $APP/ && sudo systemctl restart $SERVICE"
  echo
  echo "   查不出來就把整個畫面貼回給 AI。"
fi
echo "════════════════════════════════════════════════"
[ "$OK" = "1" ]
